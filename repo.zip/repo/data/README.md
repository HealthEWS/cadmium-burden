# Data Availability

## Required Input Files

The following data files are required to reproduce the analysis. Due to data sharing agreements and third-party licensing restrictions, raw data cannot be redistributed in this repository.

| File | Description | Source |
|------|-------------|--------|
| `raw_observations.xlsx` | Individual study-level blood cadmium measurements with country, year, sample size, GM, and GSD | Systematic review (see Supplementary Table S1) |
| `pre_pooling.xlsx` | Cleaned observations prepared for within-country weighted aggregation | Generated from Stage 1 |
| `training_68_countries.csv` | Pooled GM/GSD for 68 countries with covariates (SDI, tobacco SEV, cadmium SEV, policy duration) | GBD 2021, IHME |
| `136_new_countries_covariates.csv` | Covariate data for 136 countries without direct blood cadmium measurements | GBD 2021, IHME |

## Covariate Sources

- **Socio-demographic Index (SDI)**: Institute for Health Metrics and Evaluation, Global Burden of Disease Study 2021.
- **Tobacco Summary Exposure Value (SEV)**: IHME GBD 2021.
- **Cadmium Summary Exposure Value (SEV)**: IHME GBD 2021.
- **Policy duration**: Compiled from national regulatory databases (see Methods).

## Access

Data underlying the findings are available from the corresponding author upon reasonable request, subject to applicable data sharing agreements. Requests should be directed to [corresponding author email].

## Generated Outputs

All intermediate and final output files are written to the `output/` directory and are fully reproducible from the source data using the provided code.
