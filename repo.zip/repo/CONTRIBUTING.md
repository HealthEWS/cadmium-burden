# Contributing

Thank you for your interest in this project. This repository accompanies a peer-reviewed publication and is provided primarily for transparency and reproducibility.

## Reporting Issues

If you encounter problems reproducing the analysis, please open an issue with:

1. Your operating system and R version (`sessionInfo()` output)
2. The specific script and error message
3. Steps to reproduce the problem

## Code Changes

We welcome bug fixes and improvements. Please open an issue first to discuss proposed changes, then submit a pull request.

## Code of Conduct

This project follows the [Contributor Covenant Code of Conduct](https://www.contributor-covenant.org/version/2/1/code_of_conduct/). Please report unacceptable behaviour to the corresponding author.
