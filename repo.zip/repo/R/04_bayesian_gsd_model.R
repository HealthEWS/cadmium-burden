library(tidyverse)
library(brms)
library(bayesplot)

source("config/parameters.R")
source("R/00_utils.R")

set.seed(SEED)
options(mc.cores = parallel::detectCores())

df <- readRDS("output/training_data_standardised.rds")

fml_gsd <- bf(
  logGSD ~
    poly(year_s, 1) +
    SDI_s + cadmium_s +
    (1 | country) +
    (1 | region),
  family = gaussian()
)

priors_gsd <- c(
  prior(normal(0, 1), class = "b"),
  prior(normal(0, 5), class = "Intercept"),
  prior(exponential(1), class = "sd")
)

fit_gsd <- brm(
  formula = fml_gsd,
  data    = df,
  prior   = priors_gsd,
  family  = gaussian(),
  chains  = MCMC_CHAINS,
  iter    = MCMC_ITER,
  warmup  = MCMC_WARMUP,
  control = list(adapt_delta = GSD_ADAPT_DELTA, max_treedepth = GSD_TREEDEPTH),
  seed    = SEED,
  file    = "output/fit_gsd_model",
  refresh = 0
)

write_csv(as.data.frame(fixef(fit_gsd)), "output/gsd_fixed_effects.csv")
write_csv(as.data.frame(ranef(fit_gsd)$country), "output/gsd_random_effects_country.csv")

sink("output/gsd_model_summary.txt")
print(summary(fit_gsd))
sink()

mcmc_trace_gsd <- mcmc_trace(as.array(fit_gsd), pars = c("^b_", "^sd_", "^Intercept"))
ggsave("figures/gsd_trace.png", mcmc_trace_gsd, width = 10, height = 8, dpi = PLOT_DPI)

pp_gsd <- pp_check(fit_gsd, ndraws = 100) + ggtitle("GSD Model Posterior Predictive Check")
ggsave("figures/gsd_pp_check.png", pp_gsd, width = 8, height = 6, dpi = PLOT_DPI)
