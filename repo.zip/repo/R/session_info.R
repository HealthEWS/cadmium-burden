pkgs <- c(
  "brms", "tidyverse", "readxl", "writexl", "splines",
  "furrr", "future", "bayesplot", "MASS", "patchwork",
  "scales", "pracma", "reticulate"
)

for (p in pkgs) {
  if (!requireNamespace(p, quietly = TRUE)) {
    cat(sprintf("MISSING: %s\n", p))
  } else {
    suppressPackageStartupMessages(library(p, character.only = TRUE))
  }
}

sink("output/session_info.txt")
cat("Date:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"), "\n\n")
print(sessionInfo())
sink()

cat("Session info written to output/session_info.txt\n")
