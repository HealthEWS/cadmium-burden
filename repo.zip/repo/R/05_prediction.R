library(tidyverse)
library(brms)
library(furrr)
library(future)

source("config/parameters.R")
source("R/00_utils.R")

set.seed(SEED)
options(future.seed = TRUE)

meansds <- readRDS("output/standardisation_params.rds")
df      <- readRDS("output/training_data_standardised.rds")
fit_gm  <- readRDS("output/fit_gm_model.rds")
fit_gsd <- readRDS("output/fit_gsd_model.rds")

raw_new <- read_csv(
  "data/136_new_countries_covariates.csv",
  col_types = cols(
    country = col_character(), year = col_integer(), region = col_character(),
    SDI = col_double(), yuqishouming = col_double(),
    Tobacco_SEV = col_double(), cadmium_SEV = col_double()
  )
) %>%
  mutate(country = as.factor(country), region = as.factor(region))

new_normalised <- raw_new %>%
  mutate(
    year_s    = (year - meansds$mean_year) / meansds$sd_year,
    SDI_s     = (SDI - meansds$mean_SDI) / meansds$sd_SDI,
    policy_s  = (yuqishouming - meansds$mean_policy) / meansds$sd_policy,
    Tobacco_s = (Tobacco_SEV - meansds$mean_Tobacco) / meansds$sd_Tobacco,
    cadmium_s = (cadmium_SEV - meansds$mean_cadmium) / meansds$sd_cadmium
  ) %>%
  select(country, region, year, year_s, SDI_s, policy_s, Tobacco_s, cadmium_s)

country_means <- df %>%
  group_by(country, region) %>%
  summarise(
    SDI_bar     = mean(SDI_s, na.rm = TRUE),
    policy_bar  = mean(policy_s, na.rm = TRUE),
    Tobacco_bar = mean(Tobacco_s, na.rm = TRUE),
    cadmium_bar = mean(cadmium_s, na.rm = TRUE),
    .groups     = "drop"
  )

pred_grid_68 <- country_means %>%
  tidyr::crossing(year = YEAR_RANGE) %>%
  mutate(
    year_s    = (year - meansds$mean_year) / meansds$sd_year,
    SDI_s     = SDI_bar,
    policy_s  = policy_bar,
    Tobacco_s = Tobacco_bar,
    cadmium_s = cadmium_bar
  ) %>%
  select(country, region, year, year_s, SDI_s, policy_s, Tobacco_s, cadmium_s)

pred_grid_all <- bind_rows(pred_grid_68, new_normalised) %>%
  distinct(country, year, .keep_all = TRUE)

post_draws_gm <- posterior_epred(
  fit_gm,
  newdata           = pred_grid_all,
  allow_new_levels  = TRUE,
  sample_new_levels = "gaussian",
  ndraws            = MCMC_NDRAWS
)

post_draws_gsd <- posterior_epred(
  fit_gsd,
  newdata           = pred_grid_all,
  allow_new_levels  = TRUE,
  sample_new_levels = "gaussian",
  ndraws            = MCMC_NDRAWS
)

calc_gm_gsd <- function(log_draws) {
  tibble(
    GM_pred  = exp(mean(log_draws)),
    GSD_pred = exp(sd(log_draws))
  )
}

plan(multisession, workers = 2L)

gm_summary <- future_map_dfr(
  seq_len(ncol(post_draws_gm)),
  ~ calc_gm_gsd(post_draws_gm[, .x]),
  .progress = TRUE
)

gsd_summary <- future_map_dfr(
  seq_len(ncol(post_draws_gsd)),
  function(i) {
    samples <- exp(post_draws_gsd[, i])
    tibble(
      GSD_median = median(samples),
      GSD_lci    = quantile(samples, 0.025),
      GSD_uci    = quantile(samples, 0.975)
    )
  },
  .progress = TRUE
)

plan(sequential)

predicted_all <- bind_cols(pred_grid_all, gm_summary, gsd_summary) %>%
  mutate(
    GM_lci = GM_pred / (GSD_pred ^ 1.96),
    GM_uci = GM_pred * (GSD_pred ^ 1.96)
  ) %>%
  select(
    country, region, year,
    GM_pred, GSD_pred, GSD_median, GSD_lci, GSD_uci,
    GM_lci, GM_uci,
    year_s, SDI_s, policy_s, Tobacco_s, cadmium_s
  ) %>%
  distinct(country, year, .keep_all = TRUE)

write_csv(predicted_all, "output/predicted_204_countries_1980_2020.csv")

ensure_dir("figures/country_plots")

plan(multisession, workers = max(1L, parallel::detectCores() - 1L))

future_walk(
  unique(predicted_all$country),
  function(cty) {
    df_cty <- predicted_all %>% filter(country == cty)
    df_obs <- df %>%
      filter(as.character(country) == as.character(cty)) %>%
      select(year, GM_actual = GM)

    p <- ggplot(df_cty, aes(x = year)) +
      geom_ribbon(aes(ymin = GM_lci, ymax = GM_uci), fill = "#A6CEE3", alpha = 0.4) +
      geom_line(aes(y = GM_pred), color = "#1F78B4", linewidth = 1) +
      { if (nrow(df_obs) > 0) geom_point(data = df_obs, aes(y = GM_actual), color = "#E31A1C", size = 2) } +
      scale_x_continuous(breaks = seq(1980, 2020, 10)) +
      labs(
        title = paste0("Blood Cadmium GM: ", cty),
        x = "Year", y = expression("GM ("*mu*"g/L)")
      ) +
      theme_minimal(base_size = 14) +
      theme(plot.title = element_text(face = "bold", hjust = 0.5))

    ggsave(
      file.path("figures/country_plots", paste0(cty, ".png")),
      p, width = PLOT_WIDTH, height = PLOT_HEIGHT, dpi = PLOT_DPI
    )
  },
  .options = furrr_options(seed = SEED)
)

plan(sequential)
