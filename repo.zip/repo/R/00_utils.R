library(splines)

rolling_median_log <- function(logx, is_outlier, half_window = 2L, min_points = 3L) {
  n   <- length(logx)
  out <- rep(NA_real_, n)
  for (i in seq_len(n)) {
    idx  <- max(1L, i - half_window):min(n, i + half_window)
    vals <- logx[idx]
    ok   <- is.finite(vals) & !is_outlier[idx]
    vals <- vals[ok]
    out[i] <- if (length(vals) >= min_points) median(vals) else NA_real_
  }
  out
}

detect_upper_outliers <- function(x, k = 3) {
  lx    <- log(x)
  med   <- median(lx)
  s     <- sd(lx)
  resid <- lx - med
  resid > k * s
}

geometric_median <- function(x) {
  exp(median(log(x)))
}

make_ns_basis <- function(dose_vec, knots, boundaries) {
  splines::ns(dose_vec, knots = knots, Boundary.knots = boundaries)
}

piecewise_rr <- function(x, rcs_model, knots, boundaries,
                         threshold, asymptote, rate,
                         coef_override = NULL) {
  x_pos <- pmax(x, 1e-10)

  if (x_pos < threshold) return(1.0)

  predict_spline_rr <- function(d) {
    new_basis <- make_ns_basis(d, knots, boundaries)
    new_df    <- as.data.frame(matrix(new_basis, nrow = 1))
    colnames(new_df) <- names(coef(rcs_model))[-1]
    if (is.null(coef_override)) {
      exp(predict(rcs_model, newdata = new_df))
    } else {
      X <- as.matrix(cbind(1, new_df))
      exp(as.vector(X %*% coef_override))
    }
  }

  if (x_pos >= boundaries[1] & x_pos <= boundaries[2]) {
    return(predict_spline_rr(x_pos))
  }

  if (x_pos > boundaries[2]) {
    rr_ref   <- predict_spline_rr(boundaries[2])
    rr_value <- asymptote - (asymptote - rr_ref) * exp(-rate * (x_pos - boundaries[2]))
    return(pmax(rr_ref, pmin(rr_value, asymptote)))
  }

  1.0
}

ros_to_star <- function(ros_value, thresholds = c(0, 0.14, 0.41, 0.62)) {
  if (is.na(ros_value)) return(NA_integer_)
  if (ros_value < thresholds[1]) return(1L)
  if (ros_value <= thresholds[2]) return(2L)
  if (ros_value <= thresholds[3]) return(3L)
  if (ros_value <= thresholds[4]) return(4L)
  5L
}

ensure_dir <- function(path) {
  if (!dir.exists(path)) dir.create(path, recursive = TRUE)
  invisible(path)
}
