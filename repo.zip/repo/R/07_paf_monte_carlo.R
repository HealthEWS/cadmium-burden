library(tidyverse)
library(splines)
library(furrr)
library(future)
library(MASS)

source("config/parameters.R")
source("R/00_utils.R")

set.seed(SEED)

df <- read_csv("output/predicted_204_countries_1980_2020.csv") %>%
  rename(GM = GM_pred, GSD = GSD_pred) %>%
  filter(!is.na(GM) & !is.na(GSD) & GM > 0 & GSD > 1) %>%
  mutate(mu = log(GM), sigma = log(GSD))

rcs_fit  <- readRDS("output/rcs_fit.rds")
rcs_coef <- coef(rcs_fit)
rcs_vcov <- vcov(rcs_fit)

df <- df %>%
  mutate(
    p_exposed = 1 - plnorm(TMREL, meanlog = mu, sdlog = sigma),
    RR = map_dbl(GM, ~ piecewise_rr(
      .x, rcs_fit, RCS_KNOTS, RCS_BOUNDARIES, TMREL, RR_ASYMPTOTE, EXTRAPOLATION_RATE
    )),
    true_PAF = p_exposed * (RR - 1) / (p_exposed * (RR - 1) + 1)
  )

simulate_paf <- function(gm_val, gsd_val, n_sim = PAF_N_SIM) {
  mu    <- log(gm_val)
  sigma <- log(gsd_val)

  paf_draws <- vapply(seq_len(n_sim), function(i) {
    mu_s    <- rnorm(1, mu, sigma * PAF_EXPOSURE_NOISE)
    sigma_s <- abs(rnorm(1, sigma, sigma * PAF_EXPOSURE_NOISE))

    p_exp <- 1 - plnorm(TMREL, meanlog = mu_s, sdlog = sigma_s)

    beta_s <- as.numeric(MASS::mvrnorm(1, rcs_coef, rcs_vcov))
    gm_s   <- exp(mu_s)

    rr_val <- piecewise_rr(
      gm_s, rcs_fit, RCS_KNOTS, RCS_BOUNDARIES,
      TMREL, RR_ASYMPTOTE, EXTRAPOLATION_RATE,
      coef_override = beta_s
    )

    paf <- p_exp * (rr_val - 1) / (p_exp * (rr_val - 1) + 1)
    min(max(paf, 0), 1)
  }, numeric(1))

  tibble(
    PAF_median = median(paf_draws),
    PAF_lower  = unname(quantile(paf_draws, 0.025)),
    PAF_upper  = unname(quantile(paf_draws, 0.975))
  )
}

n_workers <- max(1L, floor(parallel::detectCores(logical = TRUE) * PARALLEL_FRACTION))
plan(multisession, workers = n_workers)

mc_results <- future_map(
  seq_len(nrow(df)),
  function(i) simulate_paf(df$GM[i], df$GSD[i]),
  .options = furrr_options(seed = TRUE)
)

plan(sequential)

df_result <- bind_cols(df, bind_rows(mc_results))

ensure_dir("output")
write_csv(df_result, "output/paf_full_results.csv")

df_result %>%
  select(country, year, GM, GSD, p_exposed, RR, true_PAF,
         PAF_median, PAF_lower, PAF_upper) %>%
  mutate(
    PAF_estimate = sprintf("%.1f%% (%.1f%%\u2013%.1f%%)",
                           PAF_median * 100, PAF_lower * 100, PAF_upper * 100),
    Exposure_pct = sprintf("%.1f%%", p_exposed * 100)
  ) %>%
  write_csv("output/paf_summary.csv")

p_trend <- ggplot(df_result, aes(x = year)) +
  geom_ribbon(aes(ymin = PAF_lower, ymax = PAF_upper), fill = "lightblue", alpha = 0.5) +
  geom_line(aes(y = PAF_median), color = "blue", linewidth = 1.2) +
  scale_y_continuous(labels = scales::percent) +
  labs(x = "Year", y = "Population Attributable Fraction") +
  theme_minimal()

ggsave("figures/paf_trend.png", p_trend, width = 10, height = 6, dpi = PLOT_DPI)
