library(readxl)
library(dplyr)
library(writexl)

source("config/parameters.R")
source("R/00_utils.R")

set.seed(SEED)

df_raw <- read_excel("data/raw_observations.xlsx", sheet = 2)

df_flagged <- df_raw %>%
  mutate(
    valid_year = !is.na(year),
    valid_GM   = !is.na(GM) & GM > 0,
    valid_GSD  = !is.na(GSD) & GSD > 0,
    valid_all  = valid_year & valid_GM & valid_GSD
  )

df_invalid <- df_flagged %>% filter(!valid_all)

df_clean <- df_flagged %>%
  filter(valid_all) %>%
  mutate(
    year = as.numeric(year),
    GM   = as.numeric(GM),
    GSD  = as.numeric(GSD)
  )

df_processed <- df_clean %>%
  group_by(country) %>%
  arrange(year) %>%
  group_modify(~ {
    d <- as.data.frame(.x)

    logGM    <- log(d$GM)
    med0_gm  <- median(logGM)
    sd0_gm   <- sd(logGM)
    resid_gm <- logGM - med0_gm
    out_gm   <- resid_gm > OUTLIER_K * sd0_gm

    logGSD    <- log(d$GSD)
    med0_gsd  <- median(logGSD)
    sd0_gsd   <- sd(logGSD)
    resid_gsd <- logGSD - med0_gsd
    out_gsd   <- resid_gsd > OUTLIER_K * sd0_gsd

    non_out_GM  <- d$GM[!out_gm]
    non_out_GSD <- d$GSD[!out_gsd]
    gm_global   <- if (length(non_out_GM) > 0) geometric_median(non_out_GM) else exp(med0_gm)
    gsd_global  <- if (length(non_out_GSD) > 0) geometric_median(non_out_GSD) else exp(med0_gsd)

    roll_gm  <- rolling_median_log(logGM, out_gm, ROLLING_HALF_W, ROLLING_MIN_PTS)
    roll_gsd <- rolling_median_log(logGSD, out_gsd, ROLLING_HALF_W, ROLLING_MIN_PTS)

    gm_local  <- exp(roll_gm)
    gsd_local <- exp(roll_gsd)

    GM_smoothed <- ifelse(out_gm,
                          ifelse(!is.na(gm_local), gm_local, gm_global),
                          d$GM)

    GSD_smoothed <- ifelse(out_gsd,
                           ifelse(!is.na(gsd_local), gsd_local, gsd_global),
                           d$GSD)

    gm_method <- ifelse(out_gm & !is.na(gm_local), "rolling_median",
                        ifelse(out_gm, "global_median_fallback", NA_character_))
    gsd_method <- ifelse(out_gsd & !is.na(gsd_local), "rolling_median",
                         ifelse(out_gsd, "global_median_fallback", NA_character_))

    is_smoothed <- out_gm | out_gsd

    d %>% mutate(
      resid_gm           = resid_gm,
      sd0_gm             = sd0_gm,
      outlier_gm         = out_gm,
      gm_med_global      = gm_global,
      gm_med_local       = gm_local,
      GM_smoothed        = GM_smoothed,
      smoothed_gm_method = gm_method,
      resid_gsd          = resid_gsd,
      sd0_gsd            = sd0_gsd,
      outlier_gsd        = out_gsd,
      gsd_med_global     = gsd_global,
      gsd_med_local      = gsd_local,
      GSD_smoothed       = GSD_smoothed,
      smoothed_gsd_method = gsd_method,
      is_smoothed        = is_smoothed
    )
  }) %>%
  ungroup()

ensure_dir("output")

write_xlsx(
  list(
    kept_data         = df_processed %>% filter(!is_smoothed),
    removed_outliers  = df_processed %>% filter(is_smoothed),
    smoothing_details = df_processed %>% filter(is_smoothed)
  ),
  path = "output/01_cleaned_observations.xlsx"
)
