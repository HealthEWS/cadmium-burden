library(readxl)
library(dplyr)
library(writexl)

source("config/parameters.R")

df <- read_excel("data/pre_pooling.xlsx") %>%
  rename(n = `人数`) %>%
  mutate(
    mu_i    = log(GM),
    sigma_i = log(GSD)
  )

df_pooled <- df %>%
  group_by(country, year) %>%
  summarise(
    jenks_group = first(jenks_group),
    N_total     = sum(n),
    mu_pooled   = sum(n * mu_i) / N_total,
    moment2     = sum(n * (sigma_i^2 + mu_i^2)) / N_total,
    var_pooled  = moment2 - mu_pooled^2,
    GM_pooled   = exp(mu_pooled),
    GSD_pooled  = exp(sqrt(var_pooled)),
    .groups     = "drop"
  )

ensure_dir("output")
write_xlsx(df_pooled, "output/02_pooled_country_year.xlsx")
