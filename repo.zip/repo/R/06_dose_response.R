library(tidyverse)
library(splines)
library(patchwork)
library(scales)

source("config/parameters.R")
source("R/00_utils.R")

set.seed(SEED)

rr_data <- tribble(
  ~Study,           ~dose, ~RR,   ~LowerCI, ~UpperCI,
  "Lars Barregard", 0.13,  1.00,  1.00,     1.00,
  "Lars Barregard", 0.21,  1.20,  0.80,     1.90,
  "Lars Barregard", 0.34,  1.30,  1.00,     2.10,
  "Lars Barregard", 0.99,  1.90,  1.10,     3.20,
  "Shinje Moon",    0.176, 1.00,  1.00,     1.00,
  "Shinje Moon",    0.285, 1.007, 0.784,    1.293,
  "Shinje Moon",    0.475, 1.211, 1.00,     1.468,
  "Shinje Moon",    0.72,  1.75,  1.413,    2.166
) %>%
  mutate(
    logRR  = log(RR),
    SE_raw = (log(UpperCI) - log(LowerCI)) / (2 * 1.96),
    SE     = if_else(SE_raw == 0, min(SE_raw[SE_raw > 0], na.rm = TRUE), SE_raw)
  )

rcs_fit <- lm(
  logRR ~ ns(dose, knots = RCS_KNOTS, Boundary.knots = RCS_BOUNDARIES),
  data    = rr_data,
  weights = 1 / SE^2
)

dose_seq_A <- seq(min(rr_data$dose), max(rr_data$dose), length.out = 300)
pred_A     <- predict(rcs_fit, newdata = tibble(dose = dose_seq_A), se.fit = TRUE)

plot_df_A <- tibble(
  dose    = dose_seq_A,
  logRR   = as.numeric(pred_A$fit),
  se_logR = as.numeric(pred_A$se.fit)
) %>%
  mutate(
    RR     = exp(logRR),
    RR_lci = exp(logRR - 1.96 * se_logR),
    RR_uci = exp(logRR + 1.96 * se_logR)
  )

pred_tmrel <- predict(rcs_fit, newdata = tibble(dose = TMREL), se.fit = TRUE)
tmrel_point <- tibble(
  dose = TMREL,
  RR     = exp(as.numeric(pred_tmrel$fit)),
  RR_lci = exp(as.numeric(pred_tmrel$fit) - 1.96 * as.numeric(pred_tmrel$se.fit))
)

dose_seq_B <- seq(0.10, 5.10, by = 0.01)
plot_df_B  <- tibble(
  dose = dose_seq_B,
  RR   = map_dbl(dose_seq_B, ~ piecewise_rr(
    .x, rcs_fit, RCS_KNOTS, RCS_BOUNDARIES, TMREL, RR_ASYMPTOTE, EXTRAPOLATION_RATE
  ))
)

COL_POINT <- "#2C7FB8"; COL_RCS <- "#C51B8A"; COL_THRESH <- "#2CA25F"
COL_EXTRA <- "#E6550D"; COL_BAND <- "#FDE0DD"; COL_KNOT <- "#636363"

base_theme <- theme_minimal(base_size = 12) +
  theme(
    plot.title    = element_text(hjust = 0.5, face = "bold", size = 16),
    axis.title    = element_text(size = 12, face = "bold"),
    panel.grid.minor = element_blank(),
    legend.position  = "none"
  )

panelA <- ggplot() +
  geom_ribbon(data = plot_df_A, aes(x = dose, ymin = RR_lci, ymax = RR_uci),
              fill = COL_BAND, alpha = 0.45) +
  geom_line(data = plot_df_A, aes(x = dose, y = RR), color = COL_RCS, linewidth = 1.4) +
  geom_point(data = rr_data, aes(x = dose, y = RR), size = 3.2, color = COL_POINT) +
  geom_hline(yintercept = 1, linetype = "dashed", color = "grey40") +
  geom_vline(xintercept = TMREL, linetype = "dashed", color = COL_THRESH) +
  geom_point(data = tmrel_point, aes(x = dose, y = RR_lci),
             color = COL_THRESH, size = 3.5, shape = 17) +
  annotate("text", x = TMREL + 0.02, y = min(plot_df_A$RR_lci) * 0.92,
           label = sprintf("TMREL = %.3f \u03bcg/L", TMREL),
           color = COL_THRESH, size = 4, fontface = "bold", hjust = 0) +
  labs(x = "Blood cadmium concentration (\u03bcg/L)", y = "Relative risk (RR)") +
  base_theme

panelB <- ggplot() +
  annotate("rect", xmin = 0, xmax = TMREL, ymin = 0.9, ymax = 1.1,
           alpha = 0.10, fill = COL_THRESH) +
  annotate("rect", xmin = TMREL, xmax = RCS_BOUNDARIES[2], ymin = 0.9, ymax = 3.0,
           alpha = 0.08, fill = COL_POINT) +
  annotate("rect", xmin = RCS_BOUNDARIES[2], xmax = 5.1, ymin = 0.9, ymax = 4.0,
           alpha = 0.08, fill = COL_EXTRA) +
  geom_line(data = plot_df_B, aes(x = dose, y = RR), color = "#D7301F", linewidth = 1.4) +
  geom_point(data = rr_data, aes(x = dose, y = RR), size = 3.2, color = COL_POINT) +
  geom_vline(xintercept = TMREL, linetype = "dashed", color = COL_THRESH) +
  geom_vline(xintercept = RCS_KNOTS, linetype = "dotted", color = COL_KNOT) +
  geom_vline(xintercept = RCS_BOUNDARIES, linetype = "longdash", color = COL_KNOT) +
  annotate("text", x = TMREL / 2, y = 1.365, label = "No risk",
           size = 3.8, color = COL_THRESH, fontface = "bold") +
  annotate("text", x = (TMREL + RCS_BOUNDARIES[2]) / 2, y = 2.45, label = "RCS model",
           size = 3.8, color = COL_POINT, fontface = "bold") +
  annotate("text", x = (RCS_BOUNDARIES[2] + 5.1) / 2, y = 3.45,
           label = "Asymptotic\nextrapolation", size = 3.8, color = COL_EXTRA, fontface = "bold") +
  labs(x = "Blood cadmium concentration (\u03bcg/L)", y = "Relative risk (RR)") +
  scale_x_continuous(limits = c(0, 5.1), breaks = 0:5, expand = c(0, 0)) +
  base_theme

combined <- panelA + panelB +
  plot_layout(ncol = 2, widths = c(0.9, 2.1)) +
  plot_annotation(tag_levels = list(c("B", "C"))) &
  theme(plot.tag = element_text(size = 28, face = "bold"))

ensure_dir("figures")
ggsave("figures/dose_response_combined.png", combined, width = 16, height = 7, dpi = PLOT_DPI, bg = "white")
ggsave("figures/dose_response_combined.pdf", combined, width = 16, height = 7, bg = "white")

saveRDS(rcs_fit, "output/rcs_fit.rds")
