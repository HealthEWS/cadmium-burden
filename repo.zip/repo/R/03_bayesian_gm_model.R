library(tidyverse)
library(readxl)
library(brms)
library(bayesplot)

source("config/parameters.R")
source("R/00_utils.R")

set.seed(SEED)
options(mc.cores = parallel::detectCores())

dataset13 <- read_csv("data/training_68_countries.csv")

meansds <- dataset13 %>%
  summarise(
    mean_year    = mean(year, na.rm = TRUE),
    sd_year      = sd(year, na.rm = TRUE),
    mean_SDI     = mean(SDI, na.rm = TRUE),
    sd_SDI       = sd(SDI, na.rm = TRUE),
    mean_policy  = mean(yuqishouming, na.rm = TRUE),
    sd_policy    = sd(yuqishouming, na.rm = TRUE),
    mean_Tobacco = mean(Tobacco_SEV, na.rm = TRUE),
    sd_Tobacco   = sd(Tobacco_SEV, na.rm = TRUE),
    mean_cadmium = mean(cadmium_SEV, na.rm = TRUE),
    sd_cadmium   = sd(cadmium_SEV, na.rm = TRUE)
  ) %>%
  as.list()

ensure_dir("output")
saveRDS(meansds, "output/standardisation_params.rds")

df <- dataset13 %>%
  drop_na(GM_pooled, GSD_pooled, SDI, yuqishouming, Tobacco_SEV, cadmium_SEV) %>%
  rename(GM = GM_pooled, GSD = GSD_pooled) %>%
  mutate(
    country   = as.factor(country),
    region    = as.factor(region),
    year      = as.integer(year),
    logGM     = log(GM),
    logGSD    = log(GSD),
    year_s    = (year - meansds$mean_year) / meansds$sd_year,
    SDI_s     = (SDI - meansds$mean_SDI) / meansds$sd_SDI,
    policy_s  = (yuqishouming - meansds$mean_policy) / meansds$sd_policy,
    Tobacco_s = (Tobacco_SEV - meansds$mean_Tobacco) / meansds$sd_Tobacco,
    cadmium_s = (cadmium_SEV - meansds$mean_cadmium) / meansds$sd_cadmium
  )

saveRDS(df, "output/training_data_standardised.rds")

fml_gm <- bf(
  logGM ~
    poly(year_s, 2) +
    policy_s + SDI_s + Tobacco_s + cadmium_s +
    year_s:SDI_s + year_s:cadmium_s +
    (1 + year_s | country) +
    (1 | region),
  family = student()
)

priors_gm <- c(
  prior(normal(0, 1), class = "b"),
  prior(normal(0, 5), class = "Intercept"),
  prior(exponential(1), class = "sd"),
  prior(gamma(2, 0.1), class = "nu")
)

fit_gm <- brm(
  formula = fml_gm,
  data    = df,
  prior   = priors_gm,
  family  = student(),
  chains  = MCMC_CHAINS,
  iter    = MCMC_ITER,
  warmup  = MCMC_WARMUP,
  control = list(adapt_delta = MCMC_ADAPT, max_treedepth = MCMC_TREEDEPTH),
  seed    = SEED,
  file    = "output/fit_gm_model",
  refresh = 0
)

write_csv(as.data.frame(fixef(fit_gm)), "output/gm_fixed_effects.csv")
write_csv(as.data.frame(ranef(fit_gm)$country), "output/gm_random_effects_country.csv")

sink("output/gm_model_summary.txt")
print(summary(fit_gm))
sink()

mcmc_trace_gm <- mcmc_trace(as.array(fit_gm), pars = c("^b_", "^sd_", "^Intercept"))
ggsave("figures/gm_trace.png", mcmc_trace_gm, width = 10, height = 8, dpi = PLOT_DPI)

pp_gm <- pp_check(fit_gm, ndraws = 100) + ggtitle("GM Model Posterior Predictive Check")
ggsave("figures/gm_pp_check.png", pp_gm, width = 8, height = 6, dpi = PLOT_DPI)
