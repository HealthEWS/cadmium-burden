library(tidyverse)
library(reticulate)
library(pracma)
library(splines)
library(MASS)

source("config/parameters.R")
source("R/00_utils.R")

SEED_MRBRT <- 20260403L
set.seed(SEED_MRBRT)

use_virtualenv("r-mrtool311", required = TRUE)
mrtool <- import("mrtool")
np     <- import("numpy")

rr_cat <- tribble(
  ~Study,            ~cat, ~dose_lb, ~dose_ub, ~RR,   ~LowerCI, ~UpperCI,
  "Lars Barregard",    1L, 0.00,     0.17,     1.000, 1.000,    1.000,
  "Lars Barregard",    2L, 0.17,     0.259,    1.200, 0.800,    1.900,
  "Lars Barregard",    3L, 0.26,     0.499,    1.300, 0.900,    2.100,
  "Lars Barregard",    4L, 0.50,     5.10,     1.900, 1.100,    3.200,
  "Shinje Moon",       1L, 0.00,     0.22,     1.000, 1.000,    1.000,
  "Shinje Moon",       2L, 0.22,     0.35,     1.007, 0.784,    1.293,
  "Shinje Moon",       3L, 0.36,     0.59,     1.211, 1.000,    1.468,
  "Shinje Moon",       4L, 0.60,     MRBRT_OPEN_UPPER, 1.750, 1.413, 2.166
) %>%
  mutate(
    dose_mid  = (dose_lb + dose_ub) / 2,
    log_rr    = log(RR),
    log_rr_se = if_else(
      RR == 1 & LowerCI == 1 & UpperCI == 1,
      NA_real_,
      (log(UpperCI) - log(LowerCI)) / (2 * qnorm(0.975))
    )
  ) %>%
  arrange(Study, cat)

ensure_dir("output")
write_csv(rr_cat, "output/mrbrt_category_input.csv")

bop_df <- rr_cat %>%
  group_by(Study) %>%
  arrange(cat, .by_group = TRUE) %>%
  mutate(
    ref_lb  = first(dose_lb),
    ref_ub  = first(dose_ub),
    ref_mid = first(dose_mid),
    ref_cat = first(cat)
  ) %>%
  filter(cat != ref_cat) %>%
  transmute(
    study_id  = Study,
    a_0 = ref_lb, a_1 = ref_ub,
    b_0 = dose_lb, b_1 = dose_ub,
    a_mid = ref_mid, b_mid = dose_mid,
    log_rr = log_rr, log_rr_se = log_rr_se
  ) %>%
  ungroup()

write_csv(bop_df, "output/mrbrt_ratio_input.csv")

midpoints_alt <- bop_df$b_mid
q15 <- as.numeric(quantile(midpoints_alt, 0.15, names = FALSE, type = 7))
q85 <- as.numeric(quantile(midpoints_alt, 0.85, names = FALSE, type = 7))

dat <- mrtool$MRData()
dat$load_df(
  data       = bop_df,
  col_obs    = "log_rr",
  col_obs_se = "log_rr_se",
  col_covs   = list("a_0", "a_1", "b_0", "b_1"),
  col_study_id = "study_id"
)

exposure_cov <- mrtool$LogCovModel(
  alt_cov  = c("b_0", "b_1"),
  ref_cov  = c("a_0", "a_1"),
  use_re   = TRUE,
  use_spline = TRUE,
  spline_knots       = np$array(MRBRT_SPLINE_KNOTS),
  spline_degree      = 3L,
  spline_knots_type  = "frequency",
  spline_l_linear    = TRUE,
  spline_r_linear    = TRUE,
  prior_spline_monotonicity = "increasing",
  name = "cadmium_exposure"
)

mod <- mrtool$MRBRT(
  data       = dat,
  cov_models = list(exposure_cov),
  inlier_pct = MRBRT_INLIER_PCT
)
mod$fit_model()

grid_x <- seq(min(rr_cat$dose_lb), max(rr_cat$dose_ub), length.out = 500)
eps    <- 1e-6

pred_df <- tibble(
  a_0 = min(rr_cat$dose_lb),
  a_1 = min(rr_cat$dose_ub[rr_cat$cat == 1]),
  b_0 = pmax(min(grid_x), grid_x - eps),
  b_1 = pmin(max(grid_x), grid_x + eps)
)

pred_dat <- mrtool$MRData()
pred_dat$load_df(data = pred_df, col_covs = list("a_0", "a_1", "b_0", "b_1"))

samples       <- mod$sample_soln(sample_size = MRBRT_N_DRAWS)
beta_samples  <- samples[[1]]
gamma_samples <- samples[[2]]

y_draws     <- mod$create_draws(
  data = pred_dat, beta_samples = beta_samples,
  gamma_samples = gamma_samples, random_study = TRUE
)
ln_rr_draws <- t(py_to_r(y_draws))

normalise_draws <- function(draw_mat, exposures, ref_exp) {
  shift <- apply(draw_mat, 1, function(z)
    approx(exposures, z, xout = ref_exp, rule = 2)$y
  )
  sweep(draw_mat, 1, shift, "-")
}

ln_rr_norm <- normalise_draws(ln_rr_draws, grid_x, min(rr_cat$dose_lb))
rr_norm    <- exp(ln_rr_norm)

bprf_ln <- apply(ln_rr_norm, 2, quantile, 0.05, na.rm = TRUE)

curve_df <- tibble(
  exposure = grid_x,
  rr_mean  = apply(rr_norm, 2, median, na.rm = TRUE),
  rr_lci   = apply(rr_norm, 2, quantile, 0.025, na.rm = TRUE),
  rr_uci   = apply(rr_norm, 2, quantile, 0.975, na.rm = TRUE),
  bprf_ln  = bprf_ln,
  bprf_rr  = exp(bprf_ln)
)

write_csv(curve_df, "output/mrbrt_curve_predictions.csv")

domain_idx <- which(curve_df$exposure >= q15 & curve_df$exposure <= q85)
ros        <- trapz(curve_df$exposure[domain_idx], curve_df$bprf_ln[domain_idx]) /
  (max(curve_df$exposure[domain_idx]) - min(curve_df$exposure[domain_idx]))

star_rating <- ros_to_star(ros, ROS_THRESHOLDS)

result_df <- tibble(
  n_studies             = n_distinct(rr_cat$Study),
  n_total_categories    = nrow(rr_cat),
  n_nonreference_points = nrow(bop_df),
  q15_exposure          = q15,
  q85_exposure          = q85,
  ros                   = round(ros, 3),
  stars                 = star_rating,
  evidence_label        = ROS_LABELS[star_rating]
)

write_csv(result_df, "output/mrbrt_ros_result.csv")

rr_old <- tribble(
  ~dose, ~RR,   ~LowerCI, ~UpperCI,
  0.13,  1.00,  1.00,     1.00,
  0.21,  1.20,  0.80,     1.90,
  0.34,  1.30,  0.90,     2.10,
  0.99,  1.90,  1.10,     3.20,
  0.176, 1.00,  1.00,     1.00,
  0.285, 1.007, 0.784,    1.293,
  0.475, 1.211, 1.00,     1.468,
  0.72,  1.75,  1.413,    2.166
) %>%
  mutate(
    logRR  = log(RR),
    SE_raw = (log(UpperCI) - log(LowerCI)) / (2 * 1.96),
    SE     = if_else(SE_raw == 0, min(SE_raw[SE_raw > 0], na.rm = TRUE), SE_raw)
  )

ns_basis_old <- ns(rr_old$dose, knots = RCS_KNOTS, Boundary.knots = RCS_BOUNDARIES)
old_fit      <- lm(
  logRR ~ .,
  data    = bind_cols(tibble(logRR = rr_old$logRR), as.data.frame(ns_basis_old)),
  weights = 1 / rr_old$SE^2
)

coef_draws_old <- MASS::mvrnorm(MRBRT_OLD_N_DRAWS, coef(old_fit), vcov(old_fit))

old_rr_vec <- function(x_vec, beta = NULL) {
  vapply(x_vec, function(x_pos) {
    x_pos <- max(x_pos, 1e-10)
    if (x_pos < TMREL) return(1.0)

    predict_old <- function(d) {
      nb <- predict(ns_basis_old, newx = d)
      X  <- c(1, as.numeric(nb))
      b  <- if (is.null(beta)) coef(old_fit) else beta
      exp(sum(X * b))
    }

    if (x_pos <= RCS_BOUNDARIES[2]) return(predict_old(x_pos))

    rr_ref   <- predict_old(RCS_BOUNDARIES[2])
    rr_value <- RR_ASYMPTOTE - (RR_ASYMPTOTE - rr_ref) *
      exp(-EXTRAPOLATION_RATE * (x_pos - RCS_BOUNDARIES[2]))
    pmax(rr_ref, pmin(rr_value, RR_ASYMPTOTE))
  }, numeric(1))
}

old_draws_mat <- t(apply(coef_draws_old, 1, function(b) old_rr_vec(grid_x, as.numeric(b))))

smooth_ci <- function(x, y, spar = 0.55) predict(smooth.spline(x, y, spar = spar), x)$y

old_curve_df <- tibble(
  exposure    = grid_x,
  rr_mean     = old_rr_vec(grid_x),
  rr_lci      = apply(old_draws_mat, 2, quantile, 0.025, na.rm = TRUE),
  rr_uci      = apply(old_draws_mat, 2, quantile, 0.975, na.rm = TRUE)
) %>%
  mutate(
    rr_lci_s = pmin(smooth_ci(exposure, rr_lci), smooth_ci(exposure, rr_uci)),
    rr_uci_s = pmax(smooth_ci(exposure, rr_lci), smooth_ci(exposure, rr_uci))
  )

curve_plot_df <- curve_df %>%
  mutate(
    rr_lci_s = pmin(smooth_ci(exposure, rr_lci), smooth_ci(exposure, rr_uci)),
    rr_uci_s = pmax(smooth_ci(exposure, rr_lci), smooth_ci(exposure, rr_uci))
  )

y_top  <- max(curve_plot_df$rr_uci_s, old_curve_df$rr_uci_s, na.rm = TRUE)
q15_bprf <- approx(curve_df$exposure, curve_df$bprf_rr, xout = q15, rule = 2)$y
q85_bprf <- approx(curve_df$exposure, curve_df$bprf_rr, xout = q85, rule = 2)$y

p_overlay <- ggplot() +
  geom_ribbon(data = curve_plot_df, aes(x = exposure, ymin = rr_lci_s, ymax = rr_uci_s),
              fill = "#9ECAE1", alpha = 0.35) +
  geom_ribbon(data = old_curve_df, aes(x = exposure, ymin = rr_lci_s, ymax = rr_uci_s),
              fill = "#F4A3A8", alpha = 0.32) +
  geom_line(data = old_curve_df, aes(x = exposure, y = rr_mean),
            color = "#D7301F", linewidth = 1.4) +
  geom_line(data = curve_plot_df, aes(x = exposure, y = rr_mean),
            color = "#2171B5", linewidth = 1.4) +
  geom_line(data = curve_df, aes(x = exposure, y = bprf_rr),
            color = "#2171B5", linewidth = 1.2, linetype = "dashed") +
  geom_point(data = rr_cat, aes(x = dose_mid, y = RR),
             shape = 21, fill = "#2C7FB8", color = "#2C7FB8", size = 3) +
  geom_hline(yintercept = 1, linetype = "dashed", color = "grey40") +
  geom_vline(xintercept = c(q15, q85), linetype = "dotted", color = "#009E73", linewidth = 1.5) +
  annotate("text", x = q15 + 0.03, y = y_top * 0.99,
           label = sprintf("15th = %.3f\nBPRF RR = %.2f", q15, q15_bprf),
           color = "#009E73", size = 4, fontface = "bold", hjust = 0, vjust = 1) +
  annotate("text", x = q85 + 0.03, y = y_top * 0.99,
           label = sprintf("85th = %.3f\nBPRF RR = %.2f", q85, q85_bprf),
           color = "#009E73", size = 4, fontface = "bold", hjust = 0, vjust = 1) +
  scale_x_continuous(limits = c(0, 5.1), breaks = 0:5, expand = c(0, 0)) +
  labs(tag = "D", x = "Blood cadmium concentration (\u00b5g/L)", y = "Relative risk (RR)") +
  theme_minimal(base_size = 12) +
  theme(
    axis.line  = element_line(linewidth = 0.6, colour = "black"),
    axis.ticks = element_line(linewidth = 0.6, colour = "black"),
    panel.grid.minor = element_blank(),
    plot.tag = element_text(size = 28, face = "bold"),
    plot.tag.position = c(0.005, 0.995)
  )

ggsave("figures/mrbrt_overlay.png", p_overlay, width = 10, height = 5, dpi = PLOT_DPI, bg = "white")
