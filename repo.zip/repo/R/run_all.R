cat("=== Blood Cadmium Global Burden Analysis Pipeline ===\n\n")

stopifnot(file.exists("config/parameters.R"))
source("config/parameters.R")
source("R/00_utils.R")

ensure_dir("output")
ensure_dir("figures")
ensure_dir("figures/country_plots")

run_stage <- function(script, label) {
  cat(sprintf("[%s] %s ...\n", format(Sys.time(), "%H:%M:%S"), label))
  t0 <- proc.time()
  source(script, local = new.env(parent = globalenv()))
  elapsed <- (proc.time() - t0)["elapsed"]
  cat(sprintf("[%s] %s completed (%.1f s)\n\n", format(Sys.time(), "%H:%M:%S"), label, elapsed))
}

run_stage("R/01_data_cleaning.R",      "Stage 1: Data cleaning")
run_stage("R/02_weighted_pooling.R",    "Stage 2: Weighted pooling")
run_stage("R/03_bayesian_gm_model.R",   "Stage 3: Bayesian GM model")
run_stage("R/04_bayesian_gsd_model.R",  "Stage 4: Bayesian GSD model")
run_stage("R/05_prediction.R",          "Stage 5: 204-country prediction")
run_stage("R/06_dose_response.R",       "Stage 6: Dose-response curves")
run_stage("R/07_paf_monte_carlo.R",     "Stage 7: PAF Monte Carlo")
run_stage("R/08_mrbrt_evidence.R",      "Stage 8: MR-BRT evidence scoring")

cat("=== Pipeline complete ===\n")
cat(sprintf("Finished at %s\n", format(Sys.time(), "%Y-%m-%d %H:%M:%S")))
