SEED <- 2025L

MCMC_CHAINS     <- 4L
MCMC_ITER       <- 4000L
MCMC_WARMUP     <- 2000L
MCMC_ADAPT      <- 0.99
MCMC_TREEDEPTH  <- 15L
MCMC_NDRAWS     <- 5000L

GSD_ADAPT_DELTA <- 0.95
GSD_TREEDEPTH   <- 12L

OUTLIER_K       <- 3
ROLLING_HALF_W  <- 2L
ROLLING_MIN_PTS <- 3L

YEAR_RANGE      <- 1980L:2020L

TMREL              <- 0.398
RR_ASYMPTOTE       <- 3.91
EXTRAPOLATION_RATE <- 0.05

RCS_KNOTS      <- c(0.20, 0.40, 0.75)
RCS_BOUNDARIES <- c(0.13, 0.99)

PAF_N_SIM          <- 5000L
PAF_EXPOSURE_NOISE <- 0.10

MRBRT_OPEN_UPPER     <- 0.83
MRBRT_N_DRAWS        <- 10000L
MRBRT_INLIER_PCT     <- 1.00
MRBRT_OLD_N_DRAWS    <- 4000L
MRBRT_SPLINE_KNOTS   <- c(0.0, 0.25, 0.50, 0.75, 1.0)

PLOT_WIDTH  <- 9
PLOT_HEIGHT <- 5
PLOT_DPI    <- 300L

PARALLEL_FRACTION <- 0.60

ROS_THRESHOLDS <- c(0.00, 0.14, 0.41, 0.62)
ROS_LABELS <- c(
  "1 star: no/insufficient conservative evidence",
  "2 stars: weak evidence",
  "3 stars: moderate evidence",
  "4 stars: strong evidence",
  "5 stars: very strong evidence"
)
